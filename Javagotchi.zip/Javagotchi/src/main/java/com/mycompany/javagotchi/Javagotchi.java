
package com.mycompany.javagotchi;


public class Javagotchi {

   public String nome;
   public int energia;
   public int fome;
   public int carinho;
   public int saude;
   public String humor;

  
    public String getNome() {
        return nome;
    }

  
    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getEnergia()
    {
        return energia;
    }
    
    public void setEnergia(int energia)
    {
        this.energia = energia;
    }
    
    
    public int getFome() {
        return fome;
    }

 
    public void setFome(int fome) {
        this.fome = fome;
    }

   
    public int getCarinho() {
        return carinho;
    }

   
    public void setCarinho(int carinho) {
        this.carinho = carinho;
    }

  
    public int getSaude() {
        return saude;
    }

   
    public void setSaude(int saude) {
        this.saude = saude;
    }
   
    public String getHumor()
    {
        return humor;
    }
    
    public void setHumor(String humor)
    {
        this.humor = humor;
    }
   
}
